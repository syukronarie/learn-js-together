import React from "react";
import Todo from "../../components/Todo/Todo";

export default function TodoPage() {
  return <Todo />;
}
