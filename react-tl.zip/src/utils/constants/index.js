const CONST = {
  baseApi: `${process.env.REACT_APP_BASE_URL}/data/v1`,
};

export default CONST;
