import React from "react";
import Followers from "../../components/Followers/Followers";

export default function FollowersPage() {
  return <Followers />;
}
